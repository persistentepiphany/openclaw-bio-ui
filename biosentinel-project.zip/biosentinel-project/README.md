# BioSentinel — Protein Structure Dashboard

A scientific data visualisation dashboard built for a university hackathon. Features a real-time 3D protein structure viewer powered by [3Dmol.js](https://3dmol.csb.pitt.edu/), surrounded by an activity feed, data table, interaction heatmap, workflow tracker, and chat interface.

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Install 3Dmol.js and jQuery (required by the viewer)
npm install 3dmol jquery

# 3. Start dev server
npm run dev
```

Open `http://localhost:5173` in a modern browser.

## Project Structure

```
src/
├── App.jsx                    # Main layout, global state management
├── components/
│   └── MoleculeViewer.jsx     # 3Dmol.js protein viewer (core component)
├── data/
│   └── mockData.js            # All mock data (activity, items, heatmap, proteins)
public/
└── pdbs/                      # (Optional) Local PDB files for faster loading
    ├── 1CRN.pdb
    ├── 4HHB.pdb
    ├── 1LYZ.pdb
    ├── 1EMA.pdb
    └── 4INS.pdb
```

## PDB Files

The viewer can load protein structures two ways:

### Option A: Local files (recommended for demo speed)

Download PDB files and place them in `public/pdbs/`:

```bash
mkdir -p public/pdbs
cd public/pdbs
curl -O https://files.rcsb.org/download/1CRN.pdb
curl -O https://files.rcsb.org/download/4HHB.pdb
curl -O https://files.rcsb.org/download/1LYZ.pdb
curl -O https://files.rcsb.org/download/1EMA.pdb
curl -O https://files.rcsb.org/download/4INS.pdb
```

### Option B: Live RCSB fetch (no setup needed)

If local files aren't found, the viewer automatically fetches from `https://files.rcsb.org/download/{PDB_ID}.pdb`. This requires internet access and may be slightly slower.

## Five Demo Proteins

| PDB  | Protein      | Residues | Chains | Features                          |
|------|-------------|----------|--------|-----------------------------------|
| 1CRN | Crambin     | 46       | 1      | α+β fold, 3 disulfide bonds      |
| 4HHB | Hemoglobin  | 574      | 4      | α₂β₂ tetramer, 4 heme groups     |
| 1LYZ | Lysozyme    | 129      | 1      | α+β, NAG substrate in active site |
| 1EMA | GFP         | 238      | 1      | β-barrel, autocatalytic chromophore|
| 4INS | Insulin     | 51       | 2      | A+B chains, Zn²⁺ ions, S-S bonds |

## Viewer Features

- **Cartoon ribbon** representation coloured by residue index (spectrum)
- **Ligand rendering**: heme groups, chromophores, substrates shown as ball-and-stick
- **Water molecules** as faint blue spheres
- **Disulfide bonds** highlighted with yellow sulfur atoms
- **Transparent molecular surface** with protein-specific colouring
- **Interactive**: drag to rotate, scroll to zoom, auto-rotation
- **Metadata overlay**: PDB code, residue/chain/atom counts, description

## Testing Different Proteins

1. Use the dropdown selector in the top-right of the viewer
2. Or change the `selectedPdb` state in `App.jsx`:
   ```jsx
   const [selectedPdb, setSelectedPdb] = useState("4HHB"); // start with Hemoglobin
   ```
3. The viewer accepts any valid PDB code — try others like `2POR` (Porin), `1BNA` (DNA)

## How MoleculeViewer.jsx Works

The component:
1. Creates a `$3Dmol.createViewer()` instance on mount
2. Fetches PDB data (local file → RCSB fallback)
3. Adds the model with `viewer.addModel(pdbData, "pdb")`
4. Applies cartoon style with spectrum colouring
5. Highlights ligands, waters, and sulfur atoms with specific styles
6. Adds a transparent molecular surface
7. Enables auto-rotation and reports structural metadata via `onLoad` callback

### Props

| Prop                | Type     | Description                                    |
|---------------------|----------|------------------------------------------------|
| `selectedMoleculeId`| `string` | PDB code (e.g. "1CRN", "4HHB")               |
| `onLoad`            | `func`   | Callback with `{ pdbId, atomCount, chains, … }`|

## Customisation

### Colour by secondary structure (instead of spectrum)

In `MoleculeViewer.jsx`, uncomment the SS-type colouring block:

```javascript
viewer.setStyle({ ss: "h" }, {
  cartoon: { color: "#e05040", opacity: 0.9, thickness: 0.35 }
});
viewer.setStyle({ ss: "s" }, {
  cartoon: { color: "#4090d0", opacity: 0.9, thickness: 0.3, arrows: true }
});
viewer.setStyle({ ss: "c" }, {
  cartoon: { color: "#808080", opacity: 0.7, thickness: 0.2 }
});
```

### Add more proteins

Add entries to `proteinList` in `src/data/mockData.js` and optionally to `PROTEIN_DB` in `MoleculeViewer.jsx` for custom ligand/surface styling.

## Tech Stack

- **React** (Vite)
- **Tailwind CSS** for styling
- **3Dmol.js** for molecular visualisation
- **jQuery** (3Dmol.js dependency)

## Credits

- PDB structures from [RCSB Protein Data Bank](https://www.rcsb.org/)
- 3Dmol.js: Rego & Koes, *Bioinformatics* (2015) 31(8):1322-1324
