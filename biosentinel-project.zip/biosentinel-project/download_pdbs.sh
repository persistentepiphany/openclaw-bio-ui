#!/bin/bash
# download_pdbs.sh — Fetch PDB files for BioSentinel demo
# Run from the project root: bash download_pdbs.sh

set -e
mkdir -p public/pdbs
cd public/pdbs

PDBS=("1CRN" "4HHB" "1LYZ" "1EMA" "4INS")

for pdb in "${PDBS[@]}"; do
  if [ -f "${pdb}.pdb" ]; then
    echo "✓ ${pdb}.pdb already exists"
  else
    echo "↓ Downloading ${pdb}.pdb..."
    curl -sO "https://files.rcsb.org/download/${pdb}.pdb"
    echo "✓ ${pdb}.pdb downloaded"
  fi
done

echo ""
echo "All PDB files ready in public/pdbs/"
ls -la *.pdb
