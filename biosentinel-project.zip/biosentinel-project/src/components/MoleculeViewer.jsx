/**
 * MoleculeViewer.jsx — 3Dmol.js-powered protein structure viewer
 *
 * Displays real PDB structures with cartoon ribbon representation,
 * secondary structure colouring, ligand highlighting, and interactive
 * orbit/zoom controls.
 *
 * Dependencies:
 *   npm install 3dmol jquery
 *
 * PDB files can be:
 *   1. Placed in public/pdbs/ (e.g. public/pdbs/1CRN.pdb)
 *   2. Fetched live from RCSB (fallback)
 *
 * Props:
 *   selectedMoleculeId  — PDB code string, e.g. "1CRN", "4HHB"
 *   onLoad              — optional callback({ pdbId, atomCount, chains })
 */

import { useEffect, useRef, useState, useCallback } from "react";

// 3Dmol.js must be imported this way (it attaches to window.$3Dmol)
import "jquery";
import $3Dmol from "3dmol/build/3Dmol-min.js";

/* ═══════════════════════════════════════════════════════════════════
   PROTEIN DATABASE
   Metadata for the five demo proteins. Secondary structure colouring
   is handled automatically by 3Dmol using the PDB HELIX/SHEET records.
   ═══════════════════════════════════════════════════════════════════ */
const PROTEIN_DB = {
  "1CRN": {
    label: "Crambin",
    desc: "Small plant protein · 46 residues · α+β fold · 3 disulfide bonds",
    organism: "Crambe hispanica",
    mw: "4.7 kDa",
    style: "cartoon",         // primary style
    ligandResnames: [],       // no heteroatom ligands
    surfaceOpacity: 0.08,
    surfaceColor: "#30d158",
  },
  "4HHB": {
    label: "Hemoglobin",
    desc: "O₂ transport tetramer · α₂β₂ · 4 heme groups with Fe²⁺",
    organism: "Homo sapiens",
    mw: "64.5 kDa",
    style: "cartoon",
    ligandResnames: ["HEM"],  // heme groups
    surfaceOpacity: 0.06,
    surfaceColor: "#ff453a",
  },
  "1LYZ": {
    label: "Lysozyme",
    desc: "Antimicrobial enzyme · 129 residues · cleaves peptidoglycan",
    organism: "Gallus gallus",
    mw: "14.3 kDa",
    style: "cartoon",
    ligandResnames: ["NAG", "NDG"],
    surfaceOpacity: 0.07,
    surfaceColor: "#5e5ce6",
  },
  "1EMA": {
    label: "GFP",
    desc: "Green fluorescent protein · 238 residues · β-barrel + chromophore",
    organism: "Aequorea victoria",
    mw: "26.9 kDa",
    style: "cartoon",
    ligandResnames: ["CRO"],  // chromophore
    surfaceOpacity: 0.06,
    surfaceColor: "#30d158",
  },
  "4INS": {
    label: "Insulin",
    desc: "Hormone dimer · A 21 + B 30 residues · 3 disulfide bonds",
    organism: "Sus scrofa",
    mw: "5.8 kDa",
    style: "cartoon",
    ligandResnames: ["ZN"],   // zinc ions
    surfaceOpacity: 0.08,
    surfaceColor: "#bf5af2",
  },
};

/* ═══════════════════════════════════════════════════════════════════
   FETCH PDB DATA
   Try local file first, then fall back to RCSB.
   ═══════════════════════════════════════════════════════════════════ */
async function fetchPdb(pdbId) {
  const id = pdbId.toUpperCase();

  // 1. Try local copy in public/pdbs/
  try {
    const localRes = await fetch(`/pdbs/${id}.pdb`);
    if (localRes.ok) {
      console.log(`[MoleculeViewer] Loaded ${id} from local file`);
      return await localRes.text();
    }
  } catch {
    // local not available, continue to RCSB
  }

  // 2. Fetch from RCSB PDB
  console.log(`[MoleculeViewer] Fetching ${id} from RCSB…`);
  const rcsbRes = await fetch(`https://files.rcsb.org/download/${id}.pdb`);
  if (!rcsbRes.ok) throw new Error(`Failed to fetch PDB ${id}: ${rcsbRes.status}`);
  return await rcsbRes.text();
}

/* ═══════════════════════════════════════════════════════════════════
   COMPONENT
   ═══════════════════════════════════════════════════════════════════ */
export default function MoleculeViewer({ selectedMoleculeId = "1CRN", onLoad }) {
  const containerRef = useRef(null);
  const viewerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(null);

  const loadStructure = useCallback(async (pdbId) => {
    const container = containerRef.current;
    if (!container) return;

    setLoading(true);
    setError(null);

    // Create or clear viewer
    if (!viewerRef.current) {
      viewerRef.current = $3Dmol.createViewer(container, {
        backgroundColor: 0x030305,
        antialias: true,
        disableFog: false,
      });
    }
    const viewer = viewerRef.current;
    viewer.clear();

    try {
      const pdbData = await fetchPdb(pdbId);
      const meta = PROTEIN_DB[pdbId.toUpperCase()] || {};

      // Add the model
      const model = viewer.addModel(pdbData, "pdb");

      // ── Cartoon ribbon coloured by secondary structure ──
      // Helices: warm red-orange, Sheets: cool blue-cyan, Loops: muted gray
      viewer.setStyle({}, {
        cartoon: {
          // Use spectrum colouring based on residue index for a clean look
          color: "spectrum",
          opacity: 0.92,
          thickness: 0.3,      // ribbon thickness
          arrows: true,        // arrowheads on beta sheets
        },
      });

      // ── Alternatively: colour by SS type (uncomment to use) ──
      // viewer.setStyle({ ss: "h" }, {
      //   cartoon: { color: "#e05040", opacity: 0.9, thickness: 0.35 }
      // });
      // viewer.setStyle({ ss: "s" }, {
      //   cartoon: { color: "#4090d0", opacity: 0.9, thickness: 0.3, arrows: true }
      // });
      // viewer.setStyle({ ss: "c" }, {
      //   cartoon: { color: "#808080", opacity: 0.7, thickness: 0.2 }
      // });

      // ── Ligands / heteroatoms ──
      if (meta.ligandResnames?.length > 0) {
        for (const resn of meta.ligandResnames) {
          // Show ligands as ball-and-stick
          viewer.setStyle({ resn }, {
            stick: { radius: 0.15, colorscheme: "Jmol" },
            sphere: { radius: 0.35, colorscheme: "Jmol" },
          });
        }
      }

      // ── Water molecules (faint dots) ──
      viewer.setStyle({ resn: "HOH" }, {
        sphere: { radius: 0.15, color: "#3478f6", opacity: 0.15 },
      });

      // ── Disulfide bonds (if present, highlight sulfurs) ──
      viewer.setStyle({ elem: "S" }, {
        sphere: { radius: 0.3, color: "#ffcc00" },
      });

      // ── Transparent molecular surface ──
      viewer.addSurface($3Dmol.SurfaceType.VDW, {
        opacity: meta.surfaceOpacity || 0.06,
        color: meta.surfaceColor || "#30d158",
      }, { hetflag: false }); // exclude heteroatoms from surface

      // ── Camera ──
      viewer.zoomTo();
      viewer.render();
      viewer.zoom(0.85, 800);  // slight pull-back with animation

      // ── Auto-rotate ──
      viewer.spin("y", 0.35);

      // ── Extract info ──
      const atoms = model.selectedAtoms({});
      const chains = new Set(atoms.map(a => a.chain)).size;
      const residues = new Set(atoms.filter(a => !a.hetflag).map(a => `${a.chain}:${a.resi}`)).size;

      const loadInfo = {
        pdbId: pdbId.toUpperCase(),
        label: meta.label || pdbId,
        desc: meta.desc || "",
        organism: meta.organism || "",
        mw: meta.mw || "",
        atomCount: atoms.length,
        chains,
        residues,
      };
      setInfo(loadInfo);
      if (onLoad) onLoad(loadInfo);

      console.log(`[MoleculeViewer] Loaded ${pdbId}: ${atoms.length} atoms, ${chains} chains, ${residues} residues`);
    } catch (err) {
      console.error(`[MoleculeViewer] Error loading ${pdbId}:`, err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [onLoad]);

  // Load structure when selectedMoleculeId changes
  useEffect(() => {
    if (selectedMoleculeId) {
      loadStructure(selectedMoleculeId);
    }
  }, [selectedMoleculeId, loadStructure]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (viewerRef.current) {
        viewerRef.current.clear();
      }
    };
  }, []);

  // Handle container resize
  useEffect(() => {
    const container = containerRef.current;
    if (!container || !viewerRef.current) return;

    const observer = new ResizeObserver(() => {
      viewerRef.current.resize();
      viewerRef.current.render();
    });
    observer.observe(container);
    return () => observer.disconnect();
  }, []);

  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      {/* 3Dmol container */}
      <div
        ref={containerRef}
        style={{
          width: "100%",
          height: "100%",
          position: "absolute",
          top: 0,
          left: 0,
          cursor: "grab",
        }}
      />

      {/* Loading overlay */}
      {loading && (
        <div style={{
          position: "absolute", inset: 0, display: "flex", flexDirection: "column",
          alignItems: "center", justifyContent: "center", gap: 12,
          background: "#030305", zIndex: 10,
        }}>
          <div style={{
            width: 20, height: 20, borderRadius: "50%",
            border: "2px solid #1a1a1a", borderTopColor: "#30d158",
            animation: "spin 0.8s linear infinite",
          }} />
          <span style={{ fontFamily: "monospace", fontSize: 11, color: "#48484a" }}>
            Loading {selectedMoleculeId}…
          </span>
          <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div style={{
          position: "absolute", inset: 0, display: "flex", alignItems: "center",
          justifyContent: "center", background: "#030305", zIndex: 10,
        }}>
          <span style={{ fontFamily: "monospace", fontSize: 12, color: "#ff453a" }}>
            Error: {error}
          </span>
        </div>
      )}

      {/* Info overlays (rendered on top of the viewer) */}
      {info && !loading && (
        <>
          {/* Top-left: SS colour legend */}
          <div style={{
            position: "absolute", top: 10, left: 10, display: "flex",
            flexDirection: "column", gap: 3, zIndex: 5,
          }}>
            {[
              { color: "#e05040", label: "α-helix" },
              { color: "#4090d0", label: "β-sheet" },
              { color: "#808080", label: "Loop/coil" },
              { color: "#ffcc00", label: "S-S / Sulfur" },
              { color: "#3478f6", label: "Water" },
            ].map((l, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 5, padding: "2px 8px",
                borderRadius: 4, background: "rgba(0,0,0,0.55)",
              }}>
                <span style={{ width: 8, height: 3, borderRadius: 1, background: l.color }} />
                <span style={{ fontFamily: "monospace", fontSize: 8, color: "#48484a" }}>{l.label}</span>
              </div>
            ))}
          </div>

          {/* Bottom-left: metadata chips */}
          <div style={{
            position: "absolute", bottom: 10, left: 10, display: "flex",
            gap: 5, flexWrap: "wrap", zIndex: 5,
          }}>
            {[
              { text: `PDB: ${info.pdbId}`, accent: true },
              { text: `${info.residues} residues` },
              { text: `${info.chains} chain${info.chains > 1 ? "s" : ""}` },
              { text: `${info.atomCount} atoms` },
              { text: info.mw },
            ].filter(c => c.text).map((c, i) => (
              <span key={i} style={{
                padding: "3px 9px", borderRadius: 5,
                background: "rgba(0,0,0,0.6)",
                fontFamily: "monospace", fontSize: 9,
                color: c.accent ? "#30d158" : "#48484a",
                border: "1px solid rgba(255,255,255,0.04)",
              }}>{c.text}</span>
            ))}
          </div>

          {/* Bottom-right: description */}
          <div style={{
            position: "absolute", bottom: 10, right: 10, padding: "5px 10px",
            borderRadius: 6, background: "rgba(0,0,0,0.6)",
            fontFamily: "monospace", fontSize: 8.5, color: "#48484a",
            border: "1px solid rgba(255,255,255,0.04)",
            maxWidth: 200, lineHeight: 1.4, zIndex: 5,
          }}>
            {info.desc}
            <br />
            <span style={{ opacity: 0.6 }}>{info.organism}</span>
          </div>
        </>
      )}
    </div>
  );
}
